Sound Effects from "Pop'n TwinBee"
Ripped directly from a PSP iso "TwinBee Portable" using PSound by MamonFighter761
No credit required if use.